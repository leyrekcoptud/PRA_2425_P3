from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='eurobot2026_vision',
            executable='vision_nav_lab',
            name='vision_nav_lab',
            output='screen'
        )
    ])

