from setuptools import setup
import os
from glob import glob

package_name = 'eurobot2026_vision'

setup(
    name=package_name,
    version='0.1.0',
    packages=[package_name],
    data_files=[
        # Índice del paquete para que ROS lo reconozca
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        # El archivo package.xml
        ('share/' + package_name, ['package.xml']),
        # IMPORTANTE: Instalar los archivos de la carpeta launch
        ('share/' + package_name + '/launch', glob('launch/*.launch.py')),
        # Instalar archivos de configuración (opcional si usas los del lab)
        ('share/' + package_name + '/config', glob('config/*.yaml')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Laura Vidal',
    maintainer_email='laura@example.com',
    description='Navegación guiada por visión para I3L7',
    license='MIT',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            # Registramos el nuevo script que procesa JSON
            'vision_nav_lab = eurobot2026_vision.vision_nav_lab:main',
        ],
    },
)
