#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from std_msgs.msg import String
from geometry_msgs.msg import Twist, TransformStamped
from tf2_ros import TransformBroadcaster
import json
import math
import time
import threading


class VisionNavLab(Node):
    def __init__(self):
        super().__init__('vision_nav_lab')

        # IDs reales de tu robot y objetivo
        self.robot_id = 5
        self.target_id = 20

        # IDs que queremos escuchar
        self.listen_ids = [5, 8, 20, 21, 22, 23]

        # Diccionario donde guardamos los datos detectados
        self.raw = {}
        self.lock = threading.Lock()

        # Publicador de TF
        self.tf_broadcaster = TransformBroadcaster(self)

        # Suscripciones dinámicas
        for tid in self.listen_ids:
            topic = f'/overhead_camera/aruco_{tid}'
            self.create_subscription(
                String,
                topic,
                lambda msg, tid=tid: self.aruco_cb(msg, tid),
                10
            )

        # Publicador de velocidades
        self.cmd_pub = self.create_publisher(Twist, '/cmd_vel', 10)

        # Timer de control
        self.create_timer(0.1, self.control_loop)

        self.get_logger().info("VisionNavLab Sprint 5 activo con TF.")

    # -----------------------------
    # CALLBACK DE ARUCO
    # -----------------------------
    def aruco_cb(self, msg: String, tid: int):
        """Recibe JSON con px, py, orientation."""
        try:
            data = json.loads(msg.data)
        except Exception:
            return

        try:
            px = float(data.get('px', 0.0))
            py = float(data.get('py', 0.0))
            orientation = float(data.get('orientation', 0.0))
        except Exception:
            return

        with self.lock:
            self.raw[tid] = {
                'px': px,
                'py': py,
                'orientation': orientation,
                'last_seen': time.time()
            }

        # Publicar TF del ArUco
        self.publish_tf(tid, px, py, orientation)

    # -----------------------------
    # PUBLICACIÓN DE TF
    # -----------------------------
    def publish_tf(self, tid, px, py, orientation):
        t = TransformStamped()
        t.header.stamp = self.get_clock().now().to_msg()
        t.header.frame_id = "map"     # Frame fijo del laboratorio
        t.child_frame_id = f"aruco_{tid}"

        t.transform.translation.x = px
        t.transform.translation.y = py
        t.transform.translation.z = 0.0

        # Convertir yaw a cuaternión
        qz = math.sin(orientation / 2.0)
        qw = math.cos(orientation / 2.0)

        t.transform.rotation.z = qz
        t.transform.rotation.w = qw

        self.tf_broadcaster.sendTransform(t)

    # -----------------------------
    # CONTROL DE NAVEGACIÓN
    # -----------------------------
    def control_loop(self):
        with self.lock:
            robot = self.raw.get(self.robot_id)
            target = self.raw.get(self.target_id)

        if robot is None or target is None:
            self.cmd_pub.publish(Twist())
            return

        dx = target['px'] - robot['px']
        dy = target['py'] - robot['py']
        dist = math.hypot(dx, dy)

        cmd = Twist()

        if dist > 25.0:
            angle_to_goal = math.atan2(dy, dx)
            yaw_err = math.atan2(
                math.sin(angle_to_goal - robot['orientation']),
                math.cos(angle_to_goal - robot['orientation'])
            )

            cmd.linear.x = min(0.15, 0.002 * dist)
            cmd.angular.z = 1.0 * yaw_err
        else:
            cmd.linear.x = 0.0
            cmd.angular.z = 0.0

        self.cmd_pub.publish(cmd)


def main(args=None):
    rclpy.init(args=args)
    node = VisionNavLab()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

